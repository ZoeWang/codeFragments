var React = require('react');
var Header = React.createClass({
	render:function(){
		return (
			<header className="jk-header">
				<h1>
				极客学院
				</h1>
			</header>
		);
	}
})
module.exports=Header;
