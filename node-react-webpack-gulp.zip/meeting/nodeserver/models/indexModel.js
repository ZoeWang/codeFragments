var indexModel={
	init:function(req,res,next){
		res.render('index/index.html');
	}
}

module.exports  = indexModel