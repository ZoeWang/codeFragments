module Cpanel::ApplicationsHelper
end
