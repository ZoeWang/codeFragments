class UserSerializer < BaseSerializer
  attributes :id, :login, :name, :avatar_url
end