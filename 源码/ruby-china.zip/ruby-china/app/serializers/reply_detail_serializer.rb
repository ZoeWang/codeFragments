class ReplyDetailSerializer < ReplySerializer
  attributes :body
end