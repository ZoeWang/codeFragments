class NodeSerializer < BaseSerializer
  attributes :id, :name, :topics_count, :summary, :section_id, :sort, :section_name, :updated_at
end