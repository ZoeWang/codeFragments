require "rails_helper"

describe PhotosController, :type => :controller do
  let(:user) { Factory :user }
end