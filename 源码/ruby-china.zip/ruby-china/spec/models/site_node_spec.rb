require 'rails_helper'

describe SiteNode, :type => :model do
end
