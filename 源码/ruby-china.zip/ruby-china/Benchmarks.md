# 页面响应时间记录

要点，所有统计都得基于有 cache 的情况，生产环境。

## 2015-5-28

- /                   = 36ms
- /topics             = 45ms
- /topics/19436       = 67ms
- /wiki               = 26ms
- /notifications      = 39ms
- /huacnlee           = 100ms
- /huacnlee/topics    = 95ms
- /huacnlee/favorites = 50ms
- /huacnlee/followers = 85ms
- /wiki/about         = 37ms
- /jobs               = 68ms
- /topics/new         = 84ms
- /sites              = 25ms
- /account/edit       = 73ms