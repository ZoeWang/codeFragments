SocialShareButton.configure do |config|
  config.allow_sites = %w(twitter facebook google_plus weibo douban)
end